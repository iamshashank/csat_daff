import React from 'react';
import { withRouter, Route, Switch } from 'react-router-dom';
import ProjectInsight from './Project_Insight.js';
import ActiveProject from './Active_Project.js';
import CsatReceived from './Csat_Received.js';
import Animate from './Animate.js';
import jdata from '../data/data.json';
import { addRoute } from "../redux/Action/addRoute";
import { connect } from 'react-redux'



class App extends React.Component {
    constructor() {
        super();
        this.state = {
            mtime: 3000
        }

    }
    // componentWillMount() {
    //     let i = 0;
    //     const data = ['3', '5', '10'];
    //     let time = 3000;
    //     const rt = ['/projectinsight', '/activeproject', '/csatreceived'];
    //     const c = setInterval(() => {
    //         // time = 3000;
    //         // let qt = Math.floor((Number(data[i]) / 4));
    //         // let rem = (Number(data[i] % 4));
    //         // if (qt >= 1 && rem === 0)
    //         //     time = time * qt;
    //         // else if (qt >= 1 && rem != 0) { time = time * (qt + 1) }
    //         // else if (qt === 0) { time = 3000; }
    //         // this.setState({ mtime: time });
    //         // console.log(qt, " ", rem, " ", time, " ", this.state.mtime);

    //         this.props.history.push(rt[i]);
    //         if (i === rt.length - 1) {
    //             i = 0;
    //         } else {
    //             i++;
    //         }
    //     }, this.state.mtime);
    // }
    componentDidMount() {
        const rt = ['/projectinsight', '/activeproject', '/csatreceived'];
        jdata.map((i, d) => {
            i.route = rt[d % 3];
        })
        this.props.changeStateToReducer(jdata)
    }
    componentWillMount() {
        //  this.props.initRedux();
        this.props.next();
    }
    handelButton() {

        let route = null;
        console.log(this.props.counter, "DATA", this.props.data);
        route = this.props.data[this.props.counter].route;
        console.log("ROUTE", route, " INDEX", this.props.counter);
        this.props.history.push(route);
        setTimeout(() => { this.props.next(); }, 3000);

    }
    render() {
        return (
            <div>
                <button onClick={this.handelButton.bind(this)} />
                <Switch>
                    <Route path='/' exact component={Animate(ProjectInsight)} />
                    <Route path='/projectinsight' exact component={Animate(ProjectInsight)} />

                    <Route path='/activeproject' exact component={Animate(ActiveProject)} />
                    <Route path='/csatreceived' exact component={Animate(CsatReceived)} />
                </Switch>
            </div>
        );
    }
}
function mapStateToProps(state) {
    console.log(state.rootRecuer);
    return ({
        data: state.rootRecuer.data,
        counter: state.rootRecuer.counter
    })
}
function mapDispatchToPropsCsat(dispatch) {
    return ({
        changeStateToReducer: (csat) => {
            dispatch(addRoute(csat))
        },
        initRedux: () => {
            dispatch({ type: "DUMMY" })
        },
        next: () => {
            console.log("CLICK");
            dispatch({ type: "NEXT" })
        }
    });
}

export default connect(mapStateToProps, mapDispatchToPropsCsat)(withRouter(App));