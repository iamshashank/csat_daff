import React from 'react';
import ap from '../media/02_Active projects.png'

class ActiveProject extends React.Component {
    render() {
        return (
            <div>
                <img src={ap} width='100%' height="50%"></img>
            </div>
        );
    }
}
export default ActiveProject;