import React from 'react';
import cr from '../media/03_Csat received.png'

class CsatReceived extends React.Component {
    render() {
        return (
            <div>
                <img src={cr} width='100%' height="50%"></img>
            </div>
        );
    }
}
export default CsatReceived;