import React from 'react';
import pn from '../media/01_Project insight.png';

class ProjectInsight extends React.Component {
    render() {
        return (
            <div>
                <img src={pn} width='100%' height="50%"></img>
            </div>
        );
    }
}
export default ProjectInsight;